using System;

public class Salones

{

 public Guid Id {get; set;}

public string Clave {get; set;}

public int Cupo {get; set;}

public string Edificio {get; set;}

}