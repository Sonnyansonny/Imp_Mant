﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using implantacion.Models;
using System.Data;
using System.Data.SqlClient;

namespace implantacion.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly string cadena = "Data Source=imsnor.database.windows.net;Initial Catalog=db;User ID=dbUserN;Password=Npas$w0rd;";
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var con = new SqlConnection(cadena);
            var cmd = new SqlCommand ("SELECT [Id],[Clave],[Cupo],[Edificio] FROM [Salones] ",con);
            
            var modelo = new List<Salones>();


            try
            {
            con.Open();
            var rdr = cmd.ExecuteReader();
             while(rdr.Read() ){

                modelo.Add(

                    new Salones 
                    {
                         Id = (Guid)rdr["Id"],
                         Clave = (string) rdr ["Clave"],
                         Cupo = (int) rdr ["Cupo"],
                         Edificio =(string) rdr ["Edificio"],
                        }//fin de new 
                );// fin de modelo 
            }//fin de while
             return View(modelo);
                                     }//fin de try

        catch (Exception  )
        {
            return Content("chale intenta mas tarde bro :) ");
        }//fin de  catch

        finally
        {
            con.Close();
        }// fin de finally

        }// fin xd

        public IActionResult Details(Guid Id )
        {
    
            var con = new SqlConnection(cadena);
            var cmd = new SqlCommand ("SELECT [Id],[Clave],[Cupo],[Edificio] FROM [Salones] WHERE Id = @Id" ,con);
            cmd.Parameters.Add("@Id",SqlDbType.UniqueIdentifier).Value =Id; 
            var modelo = new Salones();  
    
            try
            {
            con.Open();
            var rdr = cmd.ExecuteReader();

            if (rdr.Read() )
            {
                modelo.Id = (Guid)rdr ["Id"];
                modelo.Clave = (string)rdr ["Clave"];
                modelo.Cupo = (int)rdr ["Cupo"];
                modelo.Edificio = (string)rdr ["Edificio"];
            
            }// fin de if
             return View(modelo);
                                     }//fin de try

        catch (Exception  )
        {
            return Content("chale intenta mas tarde bro :) ");
        }//fin de  catch

        finally
        {
            con.Close();
        }// fin de finally


        } //fin de Details. 

        public IActionResult Create ()
        {
            return View();
        }// fin de create

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Nuevo (Salones data)
        {
        var con = new SqlConnection(cadena);
        var cmd = new SqlCommand ("INSERT INTO [Salones]( [Id],[Clave],[Cupo],[Edificio]) VALUES (Id = @Id, Clave =@Clave, Cupo=@Cupo, Edificio= @Edificio ) " ,con);
        
    cmd.Parameters.Add("@Id",SqlDbType.UniqueIdentifier).Value = Guid.NewGuid(); 
    cmd.Parameters.Add("@Clave",SqlDbType.NVarChar).Value =data.Clave; 
    cmd.Parameters.Add("@Cupo",SqlDbType.Int).Value =data.Cupo; 
    cmd.Parameters.Add("@Edificio",SqlDbType.NVarChar).Value =data.Edificio; 
   
            try
            {
            con.Open();
            cmd.ExecuteNonQuery();

             return RedirectToAction ("Index");

             }//fin de try

        catch (Exception  )
        {
            return Content("e. Message ");
        }//fin de  catch

        finally
        {
            con.Close();
        }// fin de finally
            
        }// fin de Nuevo

            public IActionResult Edit(Guid id)
        {

             var con = new SqlConnection(cadena);
            var cmd = new SqlCommand ("SELECT [Id],[Clave],[Cupo],[Edificio] FROM [Salones] WHERE Id = @Id" ,con);
            cmd.Parameters.Add("@id",SqlDbType.UniqueIdentifier).Value =id; 
            var modelo = new Salones();  
    
            try
            {
            con.Open();
            var rdr = cmd.ExecuteReader();

            if (rdr.Read() )
            {
                modelo.Id = (Guid)rdr ["Id"];
                modelo.Clave = (string)rdr ["Clave"];
                modelo.Cupo = (int)rdr ["Cupo"];
                modelo.Edificio = (string)rdr ["Edificio"];
            
            }// fin de if
             return View(modelo);
                                     }//fin de try

        catch (Exception  )
        {
            return Content("chale intenta mas tarde bro :) ");
        }//fin de  catch

        finally
        {
            con.Close();
        }// fin de finally

            
        }// fin de editar


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
